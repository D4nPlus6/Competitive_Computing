# sonnet exercise
lines = [input() for i in range(14)]
for i in lines:
    print(i.upper())

